// SPDX-License-Identifier: BSD-2-Clause-Patent
// Device-mode controller glue adapted from UniXNU/QcomDwc3 e4efe95; 21H461 ABI and PKX110 hardware are qualified separately.
#include "OriginalUsbXdciABI.h"
#include "UsbHardware.h"
#include "UsbLogHold.h"
#include "../BootProgress/PeripheralStatus.h"
#include "Sm8750Rpmh.h"
#include <IOKit/IOLib.h>
#include <IOKit/IODeviceMemory.h>
#include <IOKit/IOBufferMemoryDescriptor.h>
#include <IOKit/IOPlatformExpert.h>
#include <libkern/OSKextLib.h>
#include <kern/thread.h>
#include <pexpert/pexpert.h>
#include "AppsSmmuLock.h"
extern kmod_info_t g_kernel_kmod_info;
extern "C" {
void boot_progress_trace(const char *);
int armcpu_spi_attach(uint32_t, bool, void (*)(void *), void *, uint32_t *, uint64_t *);
int armcpu_spi_disable(uint32_t);
int armcpu_spi_enable(uint32_t);
void pagani_usb_static_init(void) __asm__("__GLOBAL__sub_I_PaganiUsb.cpp");
volatile uint32_t pagani_usb_status[24];
__attribute__((weak)) volatile uint32_t pagani_panel_probe_quiet;
}
namespace {
using namespace paganiusb;
struct Region {
    IOMemoryMap *map = nullptr;
    volatile uint32_t *va = nullptr;
    bool open(uint64_t base, uint32_t bytes) {
        IODeviceMemory *memory = IODeviceMemory::withRange(base, bytes);
        map = memory ? memory->map(kIOMapAnywhere | kIOMapInhibitCache) : nullptr;
        OSSafeReleaseNULL(memory);
        va = map ? reinterpret_cast<volatile uint32_t *>(map->getVirtualAddress()) : nullptr;
        return va != nullptr;
    }
    uint32_t read(uint32_t reg) const { return va[reg / 4]; }
    void write(uint32_t reg, uint32_t value) const { va[reg / 4] = value; __asm__ volatile("dsb sy" ::: "memory"); }
};
Region windows[WindowCount], rsc, dbWindow, smmu, spmi, owners, observer, channel;
uint32_t read(void *, Window w, uint32_t reg) { return windows[w].read(reg); }
void write(void *, Window w, uint32_t reg, uint32_t value) { windows[w].write(reg, value); }
void delay(unsigned us) { if (us >= 1000) IOSleep(us / 1000); else IODelay(us); }
const Io io = {nullptr, read, write, delay};
void statusRow() {
    char line[68];
    if (pagani_usb_status[16])
        snprintf(line, sizeof line, "USB s%d d%x p%u r%x v%x x%x", int(pagani_usb_status[0]), pagani_usb_status[1],
                 pagani_usb_status[16], pagani_usb_status[17], pagani_usb_status[18], pagani_usb_status[19]);
    else snprintf(line, sizeof line, "USB s%d d%x irq%u c%d ds%x fs%x", int(pagani_usb_status[0]),
             pagani_usb_status[1], pagani_usb_status[4], int(pagani_usb_status[15]),
             pagani_usb_status[11], pagani_usb_status[14]);
    boot_progress_io_row(PAGANI_IO_USB, line);
}
void stage(int s, uint32_t detail = 0) {
    pagani_usb_status[0] = uint32_t(s); pagani_usb_status[1] = detail;
    char line[96]; snprintf(line, sizeof line, "[usb] stage=%d detail=%x", s, detail); boot_progress_trace(line); IOLog("%s\n", line); statusRow();
}
uint32_t rpmhRead(void *ctx, uint32_t reg) { return static_cast<Region *>(ctx)->read(reg); }
void rpmhWrite(void *ctx, uint32_t reg, uint32_t value) { static_cast<Region *>(ctx)->write(reg, value); }
void rpmhDelay(void *, unsigned us) { delay(us); }
bool rails() {
    if (!dbWindow.open(0x81c60000, 0x20000) || !rsc.open(0x16520000, 0x10000)) return false;
    Sm8750CmdDb *db = static_cast<Sm8750CmdDb *>(IOMallocData(sizeof(Sm8750CmdDb)));
    if (!db) return false;
    const Sm8750RpmhIo dbIo = {&dbWindow, rpmhRead, rpmhWrite, rpmhDelay}, drv = {&rsc, rpmhRead, rpmhWrite, rpmhDelay};
    bool ok = !Sm8750CmdDbCopy(&dbIo, db);
    auto send = [&](uint32_t address, uint32_t value) {
        const Sm8750RpmhCmd command = {address, value}; Sm8750RpmhResult result = {};
        const int rc = Sm8750RpmhWriteActive(&drv, &command, 1, 1, &result);
        if (rc) pagani_usb_status[1] = uint32_t(rc);
        return rc == 0;
    };
    const struct { const char *name; uint32_t mv; } supply[] = {
        {"ldod2",880}, {"ldog3",1200}, {"ldof1",880}, {"ldob15",1800}, {"ldob5",3104}
    };
    for (const auto &s : supply) {
        uint32_t address = 0;
        if (!ok || Sm8750CmdDbVrm(db, s.name, &address)) { ok = false; break; }
        ok = send(address + 8, 7) && send(address, s.mv) && send(address + 4, 1);
    }
    Sm8750CmdDbEntry xo = {};
    if (ok) ok = !Sm8750CmdDbFind(db, "xo.lvl", Sm8750CmdDbSlaveArc, &xo) && send(xo.addr, 3);
    uint32_t address = 0, unit = 0; uint16_t width = 0; uint8_t vcd = 0;
    if (ok) ok = !Sm8750CmdDbBcm(db, "SN2", &address, &unit, &width, &vcd) && unit && width;
    if (ok) {
        uint64_t vote = ((2500000ull * width + 15) / 16 * 1000 + unit - 1) / unit;
        if (!vote) vote = 1; if (vote > 0x3fff) vote = 0x3fff;
        ok = send(address, Sm8750BcmCommand(1, 1, uint32_t(vote), uint32_t(vote)));
    }
    IOFreeData(db, sizeof(Sm8750CmdDb));
    return ok;
}
int apid(uint16_t ppid, bool writable) {
    const uint32_t count = spmi.read(4) & 0x7ffu;
    if (!count || count > 1024) return -1;
    int found = -1;
    for (uint32_t n = 0; n < count; ++n) {
        if (((spmi.read(0x2000 + n * 4) >> 8) & 0xfffu) != ppid) continue;
        if (!(owners.read(n * 4) & 7u)) return int(n);
        if (!writable) found = int(n);
    }
    return found;
}
bool pmicRead(int index, uint8_t reg, uint8_t &value) {
    if (index < 0) return false;
    const uint32_t offset = uint32_t(index) * 0x20;
    observer.write(offset, 1u << 27 | uint32_t(reg) << 4);
    for (unsigned n = 0; n < 100; ++n) {
        const uint32_t status = observer.read(offset + 8);
        if (status) { if (status != 1) return false; value = uint8_t(observer.read(offset + 0x18)); return true; }
        IODelay(10);
    }
    return false;
}
bool pmicWrite(uint8_t reg, uint8_t value) {
    channel.write(0x10, value); channel.write(0, uint32_t(reg) << 4);
    for (unsigned n = 0; n < 100; ++n) {
        const uint32_t status = channel.read(8);
        if (status) return status == 1;
        IODelay(10);
    }
    return false;
}
int cableApid = -1;
bool cablePresent;
bool repeater() {
    if (!spmi.open(0xc400000,0x3000) || !owners.open(0xc42d000,0x4000) || !observer.open(0xc440000,0x8000)) return false;
    const int index = apid(0x7fd, true);
    cableApid = apid(0x729, false);
    if (index < 0 || cableApid < 0 || !channel.open(0xc500000 + uint64_t(index)*0x1000,0x1000)) return false;
    // PKX110 device-mode repeater tuning from the running Android DT; leave host/PD ownership with the PMIC.
    const uint8_t tune[][2] = {{0x46,0x80},{0x51,0x0f},{0x52,1},{0x53,7},{0x54,4},{0x55,3},{0x57,3},{0xe8,0},{0xed,0}};
    for (const auto &v : tune) if (!pmicWrite(v[0],v[1])) return false;
    for (unsigned n = 0; n < 100; ++n) {
        uint8_t value = 0;
        if (!pmicRead(index,8,value)) return false;
        if (value & 0x80u) return true;
        IODelay(10);
    }
    return false;
}
IOBufferMemoryDescriptor *tableMemory;
unsigned bankPage;
unsigned dma() {
    if (!smmu.open(0x15000000,0x100000)) return 1;
    AppsSmmuLock lock;
    if (!lock.ready()) return 2;
    const SmmuPlan p = smmuPlan([](uint32_t r) { return smmu.read(r); });
    pagani_usb_status[16] = p.error; pagani_usb_status[17] = p.reg;
    pagani_usb_status[18] = p.value; pagani_usb_status[19] = p.other;
    if (p.error) {
        char line[96]; snprintf(line,sizeof line,"[usb] smmu plan=%u reg=%x value=%x other=%x",p.error,p.reg,p.value,p.other);
        boot_progress_trace(line); IOLog("%s\n",line);
    }
    if (p.slot == ~0u || p.bank == ~0u) return 3;
    tableMemory = IOBufferMemoryDescriptor::withOptions(IOOptionBits(kIODirectionInOut) | IOOptionBits(kIOMemoryPhysicallyContiguous), 4096, 4096);
    if (!tableMemory) return 4;
    if (tableMemory->prepare() != kIOReturnSuccess) return 5;
    auto table = static_cast<uint64_t *>(tableMemory->getBytesNoCopy());
    bzero(table,4096);
    for (uint64_t n = 2; n < 64; ++n) table[n] = n << 30 | 1ull << 10 | 3ull << 8 | 1ull << 6 | 1ull;
    for (uintptr_t at = reinterpret_cast<uintptr_t>(table); at < reinterpret_cast<uintptr_t>(table) + 4096; at += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(at) : "memory");
    __asm__ volatile("dsb sy" ::: "memory");
    const uint64_t pa = tableMemory->getPhysicalSegment(0,nullptr,0);
    if ((pa & 4095u) || pa >= dmaLimit) return 6;
    const uint32_t cb = (p.pages + p.bank) * 4096;
    smmu.write(0x800 + 4*p.slot,0);
    smmu.write(0x1800 + 4*p.bank,1);
    smmu.write(0x1000 + 4*p.bank,1u << 16 | 0xfu << 12 | 3u << 8);
    smmu.write(cb + 0x10,smmuTcr2);
    smmu.write(cb + 0x30,28u | 1u << 8 | 1u << 10 | 3u << 12 | 1u << 23);
    smmu.write(cb + 0x20,uint32_t(pa)); smmu.write(cb + 0x24,uint32_t(pa >> 32));
    smmu.write(cb + 0x28,0); smmu.write(cb + 0x2c,0); smmu.write(cb + 0x38,0xff); smmu.write(cb + 0x3c,0);
    smmu.write(cb + 0x610,0); smmu.write(cb + 0x7f0,0);
    unsigned n = 0;
    for (; n < 1000 && (smmu.read(cb + 0x7f4) & 1u); ++n) IODelay(10);
    if (n == 1000) return 7;
    smmu.write(cb + 0x58,smmu.read(cb + 0x58));
    smmu.write(cb,1u | 1u << 1 | 1u << 2 | 1u << 5 | 1u << 12);
    smmu.write(0xc00 + 4*p.slot,p.bank); smmu.write(0x800 + 4*p.slot,1u << 31 | sid);
    bankPage = p.pages + p.bank;
    pagani_usb_status[3] = p.slot | p.bank << 16;
    return (smmu.read(cb) & 1u) && smmu.read(0x800 + 4*p.slot) == (1u << 31 | sid) &&
           (smmu.read(0xc00 + 4*p.slot) & 0x3ffffu) == p.bank ? 0 : 8;
}
bool bringUp(LogHold &hold) {
    stage(2); hold.begin();
    for (unsigned n = 0; n < WindowCount; ++n) if (!windows[n].open(bases[n],sizes[n])) { stage(-1,n); return false; }
    stage(3); hold.begin();
    if (!rails()) { stage(-2,pagani_usb_status[1]); return false; }
    stage(4); hold.begin();
    if (!clocks(io)) { stage(-3); return false; }
    stage(5); hold.begin();
    if (!repeater()) { stage(-4); return false; }
    stage(6); hold.begin();
    if (!phy(io)) { stage(-5); return false; }
    stage(7); hold.begin();
    if (!core(io)) { stage(-6); return false; }
    pagani_usb_status[2] = io.rd(Core,0x120);
    stage(8); hold.begin();
    if (const unsigned error = dma()) { stage(-7,error); return false; }
    stage(9,pagani_usb_status[2]); return true;
}
}

class PaganiUsbNub : public IOService {
    OSDeclareDefaultStructors(PaganiUsbNub)
    IOInterruptAction action = nullptr;
    OSObject *owner = nullptr;
    void *context = nullptr;
    bool enabled = false, attached = false;
    static void interrupt(void *p) {
        auto self = static_cast<PaganiUsbNub *>(p);
        pagani_usb_status[4] = pagani_usb_status[4] + 1;
        if (self->enabled && self->action) self->action(self->owner,self->context,self,0);
    }
public:
    IOReturn getInterruptType(int source,int *type) override {
        if (source || !type) return kIOReturnNoInterrupt;
        *type = kIOInterruptTypeLevel; return kIOReturnSuccess;
    }
    IOReturn registerInterrupt(int source,OSObject *target,IOInterruptAction handler,void *refcon) override {
        if (source || !handler || action) return kIOReturnNoResources;
        owner = target; context = refcon; action = handler;
        if (!attached && armcpu_spi_attach(paganiusb::irq,false,interrupt,this,nullptr,nullptr) != kIOReturnSuccess) {
            action = nullptr; return kIOReturnNoResources;
        }
        attached = true; return armcpu_spi_disable(paganiusb::irq);
    }
    IOReturn unregisterInterrupt(int source) override {
        if (source) return kIOReturnNoInterrupt;
        enabled = false;
        const IOReturn result = armcpu_spi_disable(paganiusb::irq);
        if (result == kIOReturnSuccess) action = nullptr;
        return result;
    }
    IOReturn enableInterrupt(int source) override {
        if (source || !action) return kIOReturnNoInterrupt;
        enabled = true;
        const IOReturn result = armcpu_spi_enable(paganiusb::irq);
        if (result != kIOReturnSuccess) enabled = false;
        return result;
    }
    IOReturn disableInterrupt(int source) override {
        if (source) return kIOReturnNoInterrupt;
        enabled = false; return armcpu_spi_disable(paganiusb::irq);
    }
};
OSDefineMetaClassAndStructors(PaganiUsbNub,IOService)

class PaganiUsbXdci : public AppleUSBXDCI {
    OSDeclareDefaultStructors(PaganiUsbXdci)
public:
    bool start(IOService *provider) override {
        IOMemoryMap *map = provider->mapDeviceMemoryWithIndex(0,kIOMapInhibitCache);
        if (!map) return false;
        auto self = reinterpret_cast<uint8_t *>(this);
        *reinterpret_cast<IOMemoryMap **>(self + 0x230) = map;
        *reinterpret_cast<uint64_t *>(self + 0x238) = map->getVirtualAddress();
        return AppleUSBXDCI::start(provider);
    }
    bool keepConfigurations() override { return false; }
    bool transportActive() override { return true; }
    uint32_t desiredPower() override { return __atomic_load_n(&cablePresent,__ATOMIC_ACQUIRE) ? AppleUSBXDCI::desiredPower() : 0; }
    IOReturn powerOn() override {
        paganiusb::vbus(io,true); pagani_usb_status[5] = pagani_usb_status[5] + 1; return kIOReturnSuccess;
    }
    IOReturn powerOff() override {
        paganiusb::vbus(io,false); pagani_usb_status[6] = pagani_usb_status[6] + 1; return kIOReturnSuccess;
    }
    void parameters() override {
        auto fields = reinterpret_cast<uint32_t *>(reinterpret_cast<uint8_t *>(this) + 0x2410);
        fields[0] = 1; fields[1] = 0; fields[2] = 4; fields[3] = 4;
    }
    IOReturn controllerReset() override {
        const IOReturn result = AppleUSBXDCI::controllerReset();
        pagani_usb_status[7] = uint32_t(result);
        if (result != kIOReturnSuccess) return result;
        auto fields = reinterpret_cast<uint32_t *>(reinterpret_cast<uint8_t *>(this) + 0x2410);
        fields[1] = io.rd(paganiusb::Core,0x110) >> 19;
        const uint32_t width = ((io.rd(paganiusb::Core,0x140) >> 8) & 255u) | ((io.rd(paganiusb::Core,0x158) >> 8) & 3u) << 8;
        const uint32_t bytes = (io.rd(paganiusb::Core,0x15c) >> 16) * width / 8;
        uint32_t packets = bytes > 40 ? (bytes - 40) / 1024 : 1;
        fields[2] = packets > 16 ? 16 : packets ? packets : 1;
        io.bits(paganiusb::Core,0x110,3u << 12,2u << 12);
        io.bits(paganiusb::Core,0x200,1u << 6 | 1u << 8,0);
        io.bits(paganiusb::Core,0x2c0,1u << 17,0);
        io.bits(paganiusb::Core,0x700,7,0);
        return result;
    }
    void periodicStart() override {}
    void periodicStop() override {}
};
OSDefineMetaClassAndStructors(PaganiUsbXdci,AppleUSBXDCI)

namespace {
PaganiUsbXdci *publish() {
    PaganiUsbNub *nub = OSTypeAlloc(PaganiUsbNub);
    IODeviceMemory *memory = IODeviceMemory::withRange(paganiusb::bases[paganiusb::Core],0x1000);
    OSArray *ranges = memory ? OSArray::withObjects((const OSObject **)&memory,1) : nullptr;
    PaganiUsbXdci *controller = nullptr;
    if (nub && nub->init() && ranges) {
        nub->setDeviceMemory(ranges); nub->setName("usb-drd0");
        uint8_t bus = 0;
        nub->setProperty("bus-number",&bus,sizeof bus);
        char configuration[] = "standardMuxOnly";
        nub->setProperty("configuration-string",configuration,sizeof configuration);
        nub->setProperty("u1-init-disable",true); nub->setProperty("u2-init-disable",true);
        if (nub->attach(IOService::getPlatform())) {
            nub->registerService();
            controller = OSTypeAlloc(PaganiUsbXdci);
            if (!controller || !controller->init() || !controller->attach(nub) || !controller->start(nub)) {
                // An attached IRQ retains the provider for the boot; failure parks the controller without an active bus.
                paganiusb::vbus(io,false); stage(-11); controller = nullptr;
            }
        }
    }
    OSSafeReleaseNULL(ranges); OSSafeReleaseNULL(memory);
    return controller;
}
unsigned logPeriod() {
    unsigned enabled = 0, period = 3000;
    PE_parse_boot_argn("sheng-log", &enabled, sizeof enabled);
    PE_parse_boot_argn("pagani-ufslog-ms", &period, sizeof period);
    if (period < 1000) period = 1000;
    if (period > 60000) period = 60000;
    return enabled == 1 ? period : 0;
}
PaganiUsbXdci *startController() {
    LogHold hold(pagani_panel_probe_quiet, IOSleep, logPeriod());
    if (!bringUp(hold)) return nullptr;
    stage(10); hold.begin();
    const OSReturn loaded = OSKextLoadKextWithIdentifier("com.apple.driver.AppleUSBXDCI");
    pagani_usb_status[8] = uint32_t(loaded);
    if (loaded != kOSReturnSuccess && loaded != kOSKextReturnStartStopError) { stage(-9,uint32_t(loaded)); return nullptr; }
    void *handle = OSMetaClass::preModLoad(g_kernel_kmod_info.name);
    if (!handle) { stage(-10); return nullptr; }
    pagani_usb_static_init();
    if (OSMetaClass::postModLoad(handle)) { stage(-10); return nullptr; }
    stage(11); hold.begin();
    PaganiUsbXdci *controller = publish();
    if (!controller) stage(-11);
    return controller;
}
void worker(void *,wait_result_t) {
    IOSleep(3000);
    PaganiUsbXdci *controller = startController();
    if (!controller) { thread_terminate(current_thread()); return; }
    stage(12);
    int previous = -1;
    unsigned polls = 0;
    uint32_t snapshot[16] = {};
    for (;;) {
        uint8_t rt = 0;
        if (pmicRead(cableApid,0x10,rt)) {
            pagani_usb_status[10] = rt;
            const int plugged = (rt & 0x14u) == 0x10u;
            pagani_usb_status[15] = uint32_t(plugged);
            if (plugged != previous) {
                __atomic_store_n(&cablePresent,plugged != 0,__ATOMIC_RELEASE);
                IOService *resources = IOService::getResourceService();
                if (plugged) resources->setProperty("AppleUSBCableType","USBHost");
                else resources->removeProperty("AppleUSBCableType");
                stage(14, uint32_t(plugged));
                LogHold hold(pagani_panel_probe_quiet, IOSleep, logPeriod());
                hold.begin();
                pagani_usb_status[9] = uint32_t(controller->changePowerStateTo(plugged ? 4 : 0));
                pagani_usb_status[10] = rt; previous = plugged;
                stage(plugged ? 13 : 12,pagani_usb_status[9]);
            }
        } else pagani_usb_status[15] = uint32_t(-1);
        pagani_usb_status[11] = io.rd(paganiusb::Core,0x70c);
        pagani_usb_status[12] = io.rd(paganiusb::Core,0x704);
        pagani_usb_status[13] = io.rd(paganiusb::Core,0x40c);
        pagani_usb_status[14] = smmu.read(bankPage * 4096 + 0x58);
        if (!(polls++ % 4)) {
            statusRow();
            bool changed = false;
            for (unsigned n = 0; n < 16; ++n) if (snapshot[n] != pagani_usb_status[n]) changed = true;
            if (changed) {
                for (unsigned n = 0; n < 16; ++n) snapshot[n] = pagani_usb_status[n];
                char line[200];
                snprintf(line, sizeof line, "[usb] s=%d irq=%u cable=%d rt=%x power=%x reset=%x on/off=%u/%u DSTS=%x DCTL=%x EVNT=%x FSR=%x",
                         int(snapshot[0]), snapshot[4], int(snapshot[15]), snapshot[10], snapshot[9], snapshot[7],
                         snapshot[5], snapshot[6], snapshot[11], snapshot[12], snapshot[13], snapshot[14]);
                boot_progress_trace(line); IOLog("%s\n", line);
            }
        }
        IOSleep(250);
    }
}
}
extern "C" void pagani_usb_start(void) {
    unsigned mode = 0;
    if (!PE_parse_boot_argn("pagani-usb",&mode,sizeof mode) || mode != 1) return;
    static uint32_t started;
    if (__atomic_exchange_n(&started,1u,__ATOMIC_ACQ_REL)) return;
    thread_t thread = nullptr;
    pagani_usb_status[15] = uint32_t(-1);
    stage(1);
    if (kernel_thread_start(worker,nullptr,&thread) == KERN_SUCCESS) thread_deallocate(thread);
    else stage(-1);
}
