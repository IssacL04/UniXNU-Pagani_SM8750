/* SPDX-License-Identifier: MIT */
#ifndef NATIVE_ADRENO_DIAGNOSTICS_H
#define NATIVE_ADRENO_DIAGNOSTICS_H
#include <stdint.h>

struct NativeAdrenoDiagnostics {
    uint32_t opens,closes,busy,calls,last_status;
    uint32_t submissions,completed,timeouts,poisoned;
    char opener[17];
};
/* Diagnostic counters are approximate. A busy GPU leaves the output untouched. */
extern "C" bool native_adreno_diagnostics(NativeAdrenoDiagnostics *);
#endif
