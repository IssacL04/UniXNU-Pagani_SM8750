#!/usr/bin/env python3
"""Exercise the actual board SMMU checks and status rows with software peers."""
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT.parent / 'UniXNU'
GPU = MAIN / 'drivers/Adreno740'
board = (ROOT / 'package/PaganiGpu.cpp').read_text()
prepare = 'int prepare_smmu()' + board.split('int prepare_smmu()', 1)[1].split('int prepare_memory()', 1)[0]
status = 'extern "C" int pagani_gpu_status' + board.split('extern "C" int pagani_gpu_status', 1)[1]
report = (GPU / 'NativeAdrenoGmuContext.h').read_text().split('struct NativeAdrenoGmuContextReport {', 1)[1].split('\n};', 1)[0]

source = r'''
#include <cassert>
#include <cstdio>
#include <cstring>
#include <array>
#include "ArmSmmu4KContext.h"
#include "ArmSmmu4KMmio.h"
#include "NativeAdrenoDiagnostics.h"
#include "PeripheralStatus.h"
using IOReturn=int;
struct NativeAdrenoGmuContextReport {
''' + report + r'''
};
static unsigned reads,writes,fail_read,fail_write,gmu_calls,gpu_calls;
static int bind_rc,gmu_rc,gpu_rc;
static bool bad_actlr;
static std::array<uint32_t,0x40000/4> regs;
struct Window {
    volatile uint8_t *cpu=reinterpret_cast<volatile uint8_t *>(regs.data());
    size_t bytes=0x40000;
    int read(size_t at,uint32_t *v) {
        assert(!(at&3) && at<bytes);if(++reads==fail_read)return -1;
        *v=regs[at/4];return 0;
    }
    int write(size_t at,uint32_t v) {
        assert(!(at&3) && at<bytes);if(++writes==fail_write)return -1;
        regs[at/4]=bad_actlr?0:v;return 0;
    }
};
ArmSmmu4KStatus ArmSmmu4KBindMmio(ArmSmmu4KMmio *,ArmSmmu4KIo *)
{return static_cast<ArmSmmu4KStatus>(bind_rc);}
static int fill(NativeAdrenoGmuContextReport *r,int rc) {
    r->id2=0x22;r->step=3;r->status=rc;r->program_phase=6;
    r->program_status=8;r->route_phase=2;r->route_status=4;r->mismatch=0x80;return rc;
}
struct Gmu {
    int bringUp(const ArmSmmu4KIo *,unsigned bank,unsigned asid,unsigned slot,uint16_t sid,
                void (*)(uint32_t),NativeAdrenoGmuContextReport *r) {
        assert(bank==1 && asid==1 && slot==2 && sid==5);++gmu_calls;return fill(r,gmu_rc);
    }
};
constexpr uint32_t NativeAdrenoChipA830=0x44050001;
struct Gpu {
    bool done=false;
    bool ready() {return done;}
    int bringUp(const ArmSmmu4KIo *,unsigned bank,unsigned asid,const unsigned *slots,const uint16_t *sids,
                void (*)(uint32_t),NativeAdrenoGmuContextReport *r,uint32_t chip) {
        assert(bank==0 && asid==2 && slots[0]==0 && slots[1]==1 && sids[0]==0 && sids[1]==1);
        assert(chip==NativeAdrenoChipA830);++gpu_calls;done=!gpu_rc;return fill(r,gpu_rc);
    }
};
static struct {
    Window smmu;
    size_t bank_offset[2]{},smmu_offset=0;
    uint32_t smmu_id1=0,smmu_value=0;
    unsigned smmu_context=0;
    ArmSmmu4KMmio smmu_mmio{};
    ArmSmmu4KIo smmu_io{};
    Gmu gmu_context;
    Gpu gpu_context;
    NativeAdrenoGmuContextReport gmu_report{},gpu_report{};
    struct {unsigned stage=0,window=0,offset=0,value=0;} power;
    struct {struct {unsigned phase=0,firmware_init_result=0,hfi_status=0;} load;unsigned protocol_status=0;} gmu_result;
} g;
static unsigned native_adreno_pool_mib,native_adreno_wc_enabled;
static const char *current_stage="GPU SMMU";
static int startup_result;
static void stage(const char *name) {current_stage=name;}
extern "C" bool native_adreno_diagnostics(NativeAdrenoDiagnostics *) {return false;}
static void *native_adreno_published_service() {return nullptr;}
''' + prepare + status + r'''
static void reset() {
    g={};regs.fill(0);regs[0x24/4]=0x40000008;
    reads=writes=fail_read=fail_write=gmu_calls=gpu_calls=0;
    bind_rc=gmu_rc=gpu_rc=0;bad_actlr=false;
}
static void check_rows(const char *where,const char *detail) {
    char rows[PAGANI_GPU_ROWS][PAGANI_STATUS_BYTES];
    const auto before=regs;unsigned n=reads,w=writes;
    assert(pagani_gpu_status(rows)==1);
    assert(strstr(rows[0],where) && strstr(rows[1],"not published"));
    assert(strstr(rows[2],"SMMU i1=") && strstr(rows[3],detail));
    for(auto &row:rows)assert(memchr(row,0,sizeof row));
    assert(n==reads && w==writes && before==regs);
}
int main() {
    reset();assert(!prepare_smmu() && g.gpu_context.ready() && reads==5 && writes==2);
    assert(gmu_calls==1 && gpu_calls==1 && regs[0x20004/4]==0x32b && regs[0x21004/4]==0x32b);
    for(uint32_t id:{0u,1u,0x40010008u,0x70000008u}) {
        reset();regs[0x24/4]=id;startup_result=prepare_smmu();assert(startup_result==-95 && !writes && !gmu_calls);
        check_rows("GPU SMMU ID","c=0");
    }
    for(unsigned bank=0;bank<2;++bank) {
        reset();regs[(0x20000+bank*0x1000)/4]=1;startup_result=prepare_smmu();
        assert(startup_result==-16 && !writes && !gmu_calls && g.smmu_value==1);
        assert(g.smmu_offset==0x20000+bank*0x1000);check_rows("GPU SMMU banks","c=0");
    }
    for(unsigned i=1;i<=5;++i) {
        reset();fail_read=i;assert(prepare_smmu()==-5 && !gmu_calls && reads==i && g.smmu_value==~0u);
    }
    for(unsigned i=1;i<=2;++i) {
        reset();fail_write=i;assert(prepare_smmu()==-5 && !gmu_calls && writes==i);
    }
    reset();bad_actlr=true;assert(prepare_smmu()==-5 && writes==1 && !gmu_calls);
    check_rows("GPU SMMU ACTLR","c=0");
    reset();bind_rc=ArmSmmu4KArgument;assert(prepare_smmu()==bind_rc && !gmu_calls);
    check_rows("GPU SMMU bind","c=0");
    reset();gmu_rc=-60;startup_result=prepare_smmu();assert(startup_result==-60 && gmu_calls==1 && !gpu_calls);
    check_rows("GPU SMMU GMU","c=1 s=3 p=6/8 r=2/4 mm=80");
    reset();gpu_rc=-70;startup_result=prepare_smmu();assert(startup_result==-70 && gmu_calls==1 && gpu_calls==1);
    check_rows("GPU SMMU GPU","c=2 s=3 p=6/8 r=2/4 mm=80");
    reset();assert(!prepare_smmu());char rows[PAGANI_GPU_ROWS][PAGANI_STATUS_BYTES];
    assert(pagani_gpu_status(rows)==1 && strstr(rows[2],"P step=") && strstr(rows[3],"GMU p="));
    puts("PASS: actual SMMU preflight, busy-bank refusal, ACTLR and I/O failures, context error propagation and MMIO-free diagnostics");
}
'''
with tempfile.TemporaryDirectory(prefix='pagani-smmu-') as directory:
    work = Path(directory)
    test = work / 'smmu.cpp'
    test.write_text(source)
    binary = work / 'smmu'
    subprocess.run([os.environ.get('CXX', 'c++'), '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
                    '-fsanitize=address,undefined', '-I', str(MAIN / 'kits/ArmSmmu4K'), '-I', str(GPU),
                    '-I', str(ROOT.parent / 'UniXNU-Pagani-Drivers/drivers/BootProgress'),
                    str(test), '-o', str(binary)], check=True)
    subprocess.run([binary], check=True)
