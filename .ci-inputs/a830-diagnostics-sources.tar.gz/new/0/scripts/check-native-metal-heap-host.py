#!/usr/bin/env python3
"""Check the real Metal heap bridge against a host Vulkan loader; no phone GPU claim."""
import argparse
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--loader', type=Path, required=True)
args = parser.parse_args()
if sys.platform != 'darwin' or not args.loader.is_file():
    parser.error('Requires macOS and a host Vulkan loader')
subprocess.run([sys.executable, root / 'scripts/build-adreno-metal-bridge.py', '--target', 'host'], check=True)
kit = root / 'drivers/AdrenoMetal'
out = root / 'build/metal-heap-host'
out.mkdir(parents=True, exist_ok=True)
cache = out / 'cache'
cache.mkdir(exist_ok=True)
original = (kit / 'NativeBridgeMetalFrontend.mm').read_text()
negative = original
for kind in ('buffer', 'texture'):
    call = f'nmb_{kind}_make_aliasable(_handle)'
    assert negative.count(call) == 1
    negative = negative.replace(call, 'true /* missing alias transition */')
for label, source in [('fixed', original), ('old', negative)]:
    path = out / (label + '.mm')
    path.write_text(source)
    exe = out / label
    subprocess.run(['xcrun', 'clang++', '-std=c++17', '-O1', '-fobjc-arc', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-parameter', '-Wno-deprecated-declarations', '-I', kit,
                    path, kit / 'bridge/heap_aliasing_host.mm',
                    root / 'build/adreno-metal-bridge/host/libadreno_metal_bridge.a',
                    '-framework', 'Foundation', '-framework', 'Metal', '-framework', 'IOSurface',
                    '-framework', 'CoreFoundation', '-o', exe], check=True)
    result = subprocess.run([exe, args.loader.resolve(), cache], text=True, capture_output=True, timeout=120)
    (out / (label + '.log')).write_text(result.stdout + result.stderr)
    if label == 'fixed':
        if result.returncode or 'PASS:' not in result.stdout:
            raise SystemExit('Heap reuse failed: ' + (result.stdout + result.stderr)[-6000:])
        print(result.stdout, end='')
    elif result.returncode != 1 or 'first.isAliasable && heap.usedSize==8192' not in result.stderr:
        raise SystemExit('Old-code control failed unexpectedly: ' + (result.stdout + result.stderr)[-3000:])
    else:
        print('PASS: missing alias transition fails retained-resource reuse')
