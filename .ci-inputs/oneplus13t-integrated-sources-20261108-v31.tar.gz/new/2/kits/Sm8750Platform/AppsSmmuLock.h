// SPDX-License-Identifier: BSD-2-Clause-Patent
#pragma once
#include <stdint.h>
extern "C" { __attribute__((weak)) uint32_t sm8750_apps_smmu_busy; }
// Late peripheral threads share the stream table; early UFS setup finishes before they start.
class AppsSmmuLock {
    bool held = false;
public:
    AppsSmmuLock() {
        for (unsigned i = 0; i < 2000; ++i) {
            uint32_t expected = 0;
            if (__atomic_compare_exchange_n(&sm8750_apps_smmu_busy, &expected, 1u, false,
                                            __ATOMIC_ACQUIRE, __ATOMIC_RELAXED)) { held = true; break; }
            IOSleep(1);
        }
    }
    ~AppsSmmuLock() { if (held) __atomic_store_n(&sm8750_apps_smmu_busy, 0u, __ATOMIC_RELEASE); }
    bool ready() const { return held; }
    AppsSmmuLock(const AppsSmmuLock &) = delete;
    AppsSmmuLock &operator=(const AppsSmmuLock &) = delete;
};
