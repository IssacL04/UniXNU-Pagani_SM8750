#!/usr/bin/env python3
"""Exercise locked sparse source installation from a fresh clone."""
import importlib.util
from pathlib import Path
import tempfile

spec = importlib.util.spec_from_file_location('fetch', Path(__file__).with_name('fetch-sources.py'))
fetch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fetch)

with tempfile.TemporaryDirectory(prefix='wifi-source-test-') as directory:
    root = Path(directory)
    source = root / 'upstream'
    source.mkdir()
    fetch.git(source, 'init', '-q', '-b', 'fixture')
    fetch.git(source, 'config', 'user.name', 'Source test')
    fetch.git(source, 'config', 'user.email', 'test@example.invalid')
    for name in ('include/fixture.h', 'lib/selected.c', 'lib/unselected.c'):
        path = source / name
        path.parent.mkdir(exist_ok=True)
        path.write_text(name + '\n')
    fetch.git(source, 'add', '.')
    fetch.git(source, 'commit', '-qm', 'Locked sources')
    fetch.ROOT = root / 'component'
    (fetch.ROOT / 'deps').mkdir(parents=True)
    lock = {'url': source.as_uri(), 'ref': 'fixture',
            'commit': fetch.git(source, 'rev-parse', 'HEAD'),
            'paths': ['/include/', '/lib/selected.c'],
            'required': ['include/fixture.h', 'lib/selected.c']}
    installed = fetch.resolve('fixture', lock, False)
    assert fetch.resolve('fixture', lock, True) == installed
    assert not (fetch.ROOT / 'deps/fixture/lib/unselected.c').exists()
print('PASS: fresh sparse clone installs directories and individual locked files')
