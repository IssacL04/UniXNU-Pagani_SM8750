#!/usr/bin/env python3
"""Exercise controller bring-up without touching hardware."""
from pathlib import Path
import os
import subprocess
import tempfile

source = Path(__file__).resolve().parents[1]
workspace = source.parents[2]
kit = workspace / 'UniXNU-sm8750-common/kits/Sm8750Platform'
if not kit.is_dir():
    kit = Path.cwd() / 'kits/Sm8750Platform'
with tempfile.TemporaryDirectory(prefix='pagani-usb-test-') as tmp:
    binary = Path(tmp) / 'hardware'
    subprocess.run([os.environ.get('CXX','c++'),'-std=c++17','-Wall','-Wextra','-Werror',
                    '-fsanitize=address,undefined','-I',str(kit),str(source / 'Test/hardware.cpp'),'-o',str(binary)],check=True)
    subprocess.run([str(binary)],check=True)
