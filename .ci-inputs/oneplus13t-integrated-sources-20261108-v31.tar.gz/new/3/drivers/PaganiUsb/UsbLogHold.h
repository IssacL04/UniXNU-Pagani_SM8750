// SPDX-License-Identifier: BSD-2-Clause-Patent
#pragma once
#include <stdint.h>
namespace paganiusb {
// Leave a breadcrumb on UFS, then let the writer's final round drain before risky hardware access.
class LogHold {
    volatile uint32_t &word;
    void (*sleep)(unsigned);
    unsigned period;
    static constexpr uint32_t bit = 1u << 7;
public:
    LogHold(volatile uint32_t &word, void (*sleep)(unsigned), unsigned period) : word(word), sleep(sleep), period(period) {}
    void release() { if (period) __atomic_fetch_and(&word, ~bit, __ATOMIC_RELEASE); }
    void begin() {
        if (!period) return;
        release();
        sleep(period + 500);
        __atomic_fetch_or(&word, bit, __ATOMIC_RELEASE);
        sleep(1000);
    }
    ~LogHold() { release(); }
};
}
