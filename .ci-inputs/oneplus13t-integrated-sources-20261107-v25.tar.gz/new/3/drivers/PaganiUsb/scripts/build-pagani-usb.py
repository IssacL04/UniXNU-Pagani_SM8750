#!/usr/bin/env python3
"""Qualify the original 21H461 USB device ABI and build the PKX110 controller."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

SOURCE = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(value, message):
    if not value:
        raise ValueError(message)


def qualify(original):
    table = original.pointers(0xfffffff005ef3710, 267)
    service = original.pointers(original.names['__ZTV9IOService'] + 16, 168)
    require(all(table) and original.read(0xfffffff005ef3710 + 267 * 8, 24) == bytes(24), 'USB vtable extent')
    require([i for i, value in enumerate(table) if value == original.names['___cxa_pure_virtual']] ==
            [179, 255, 256, 257, 258, 264, 265], 'USB abstract methods')
    require([i for i in range(168) if table[i] != service[i]] == [0,1,7,14,21,44,76,86,87,111,117], 'USB IOService overrides')
    witnesses = {
        0xfffffff0055420b4: 'fd7bbfa9fd030091955c0094884d00b008411c91080000f9fd7bc1a8c0035fd6',
        0xfffffff0055420d4: '925c0014',
        0xfffffff0055420e0: '20af00f000400091c0035fd6',
        0xfffffff00555a250: '601a01f9e00700b4080040f9083d40f900013fd6601e01f9',
        0xfffffff005543b50: '081c41f9024921b8c0035fd6',
        0xfffffff00555aa3c: 'e880ff9000d5c13d0004893dc0035fd6',
    }
    # Field accesses and constructors are checked in addition to the image hash and vtable slots.
    for address, expected in witnesses.items():
        require(original.read(address, len(bytes.fromhex(expected))).hex() == expected, f'USB ABI witness {address:#x}')
    require(table[263] == 0xfffffff00554dbd4 and original.read(0xfffffff0045709a9,16) == b'controllerReset\0', 'USB reset method')
    return table, service


def header(out):
    text = '''// SPDX-License-Identifier: BSD-2-Clause-Patent
// Generated only after exact 21H461 image and field qualification.
#pragma once
#include <IOKit/IOService.h>
class AppleUSBXDCI : public IOService {
 OSDeclareAbstractStructors(AppleUSBXDCI)
 unsigned char originalPrivate[0x2440-sizeof(IOService)];
public:
 void free() override;
 bool init(OSDictionary *properties=nullptr) override;
 IOReturn setProperties(OSObject *) override;
 bool willTerminate(IOService *,IOOptionBits) override;
 bool start(IOService *) override;
 void stop(IOService *) override;
 IOWorkLoop *getWorkLoop() const override;
 IOReturn callPlatformFunction(const OSSymbol *,bool,void *,void *,void *,void *) override;
'''
    methods = {179:'bool keepConfigurations()=0', 227:'uint32_t desiredPower()', 255:'bool transportActive()=0',
               256:'IOReturn powerOn()=0', 257:'IOReturn powerOff()=0', 258:'void parameters()=0',
               263:'IOReturn controllerReset()', 264:'void periodicStart()=0', 265:'void periodicStop()=0'}
    for slot in range(168,267):
        text += ' virtual ' + methods.get(slot, f'void opaque{slot}()') + ';\n'
    text += '};\nstatic_assert(sizeof(AppleUSBXDCI)==0x2440,"Original USB instance extent");\n'
    (out / 'OriginalUsbXdciABI.h').write_text(text)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tree', type=Path, default=Path.cwd())
    p.add_argument('--kernelcache', type=Path, required=True)
    p.add_argument('--append-to', type=Path)
    p.add_argument('--audit-only', action='store_true')
    a = p.parse_args()
    tree = a.tree.resolve()
    sys.path.insert(0,str(tree / 'scripts'))
    from original_stage7 import OriginalImage
    peripheral = load('peripheral', tree / 'scripts/build-pagani-peripherals.py')
    battery = load('battery', SOURCE.parent / 'PaganiBattery/scripts/build-pagani-battery.py')
    original = OriginalImage(a.kernelcache)
    table, service = qualify(original)
    out = tree / 'build/pagani-usb'
    out.mkdir(parents=True, exist_ok=True)
    header(out)
    if a.audit_only:
        print('PASS: exact 21H461 USB controller ABI and field accesses')
        return
    record = battery.load_record(tree, battery.CXX_RECORD)
    flags = ['-I',str(SOURCE),'-I',str(out),'-I',str(tree / '.cache/xnu-work/osfmk'),
             '-I',str(tree / 'kits/Sm8750Platform'),
             '-I',str(tree / 'drivers/Adreno830/platform/sm8750'),'-mgeneral-regs-only',*battery.WARNINGS,
             '-Wno-missing-field-initializers']
    obj = battery.compile_one(record,SOURCE / 'PaganiUsb.cpp',out / 'PaganiUsb.o',flags)
    symbols, slots = peripheral.symbols_and_slots(obj,'PaganiUsbXdci',267)
    bindings = {'__ZN12AppleUSBXDCIC2EPK11OSMetaClass':0xfffffff0055420b4,
                '__ZN12AppleUSBXDCID2Ev':0xfffffff0055420d4,
                '__ZN12AppleUSBXDCI10gMetaClassE':0xfffffff006b29010,
                '__ZTV12AppleUSBXDCI':0xfffffff005ef3700,
                '__ZN12AppleUSBXDCI15controllerResetEv':table[263],
                '__ZN12AppleUSBXDCI12desiredPowerEv':table[227]}
    own = []
    for i, name in enumerate(slots):
        if name.startswith(('__ZN13PaganiUsbXdci','__ZNK13PaganiUsbXdci')):
            own.append(i)
        elif '12AppleUSBXDCI' in name:
            require(i not in (179,255,256,257,258,264,265),'Original abstract slot inherited')
            bindings[name] = table[i]
        else:
            require(i < 168 and table[i] == service[i] == original.names.get(name),f'USB slot {i} reaches its original base')
    require(own == [0,1,7,86,179,227,255,256,257,258,263,264,265],f'USB native overrides: {own}')
    undefined = {n for n,_,kind in symbols if kind == 1 and '12AppleUSBXDCI' in n}
    require(undefined <= bindings.keys(),f'Unknown original imports: {undefined-bindings.keys()}')
    asm = out / 'usb-bindings.S'
    asm.write_text(''.join(f'.globl {n}\n.set {n}, {bindings[n]:#x}\n' for n in sorted(undefined)))
    bound = out / 'usb-bindings.o'
    subprocess.run(['xcrun','clang','-target','arm64-apple-ios17.0','-c',str(asm),'-o',str(bound)],check=True)
    late = out / 'PaganiUsb.late.o'
    subprocess.run([battery.tool('llvm-objcopy'),'--remove-section=__DATA,__mod_init_func',
                    '--globalize-symbol=__GLOBAL__sub_I_PaganiUsb.cpp',str(obj),str(late)],check=True)
    require(battery.text(obj) == battery.text(late) and not any(s == '__mod_init_func' for _,s in battery.sections(late)),
            'USB late registration preserves instructions')
    archive = out / 'libPaganiUsb.a'
    archive.unlink(missing_ok=True)
    subprocess.run(['xcrun','ar','rcs',str(archive),str(late),str(bound)],check=True)
    if a.append_to:
        require(a.append_to.is_file(),'Adreno830 archive must be built before USB')
        subprocess.run(['xcrun','ar','rcs',str(a.append_to),str(late),str(bound)],check=True)
        require(not {n:m for n,m in battery.strong_per_member(a.append_to).items() if len(m)>1},'Duplicate strong USB definitions')
    (out / 'abi-audit.json').write_text(json.dumps(dict(original_sha256=original.sha256,slots=267,overrides=own,
        bindings={n:bindings[n] for n in sorted(undefined)},runtime_qualified=False),indent=2)+'\n')
    print('PASS: PKX110 USB device-mode archive and exact 21H461 ABI bindings')


if __name__ == '__main__':
    main()
