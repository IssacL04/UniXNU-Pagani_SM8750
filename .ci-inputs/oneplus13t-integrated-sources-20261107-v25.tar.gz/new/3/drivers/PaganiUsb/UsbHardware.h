// SPDX-License-Identifier: BSD-2-Clause-Patent
#pragma once
#include <stdint.h>

// PKX110 live DT and Linux gcc-sm8750/phy-qcom-m31-eusb2 register facts.
namespace paganiusb {
enum Window { Gcc, Tcsr, Phy, Scratch, Core, WindowCount };
constexpr uint64_t bases[] = {0x100000, 0xf206000, 0x88e3000, 0xa6f8000, 0xa60c000};
constexpr uint32_t sizes[] = {0x60000, 0x1000, 0x1000, 0x1000, 0x1000};
constexpr unsigned irq = 165;
constexpr uint16_t sid = 0x40;
struct Io {
    void *context;
    uint32_t (*read)(void *, Window, uint32_t);
    void (*write)(void *, Window, uint32_t, uint32_t);
    void (*delay)(unsigned);
    uint32_t rd(Window w, uint32_t r) const { return read(context, w, r); }
    void wr(Window w, uint32_t r, uint32_t v) const { write(context, w, r, v); }
    bool bits(Window w, uint32_t r, uint32_t mask, uint32_t value) const {
        wr(w, r, (rd(w, r) & ~mask) | value);
        return (rd(w, r) & mask) == value;
    }
    bool wait(Window w, uint32_t r, uint32_t mask, uint32_t value) const {
        for (unsigned n = 0; n < 1000; ++n) {
            if ((rd(w, r) & mask) == value) return true;
            delay(100);
        }
        return false;
    }
};
inline bool clocks(const Io &io) {
    const uint32_t domains[] = {0x50018, 0x39004};
    for (uint32_t r : domains) {
        if (!io.bits(Gcc, r, 1u | (1u << 11), 1u << 11) || !io.wait(Gcc, r, 1u << 31, 1u << 31)) return false;
    }
    if (!io.bits(Gcc, 0x39000, 1, 1)) return false;
    io.delay(20);
    if (!io.bits(Gcc, 0x39000, 1, 0)) return false;
    const uint32_t roots[][2] = {{0x39030, 0x105}, {0x39048, 0}};
    for (const auto &r : roots) {
        if (!io.bits(Gcc, r[0] + 4, 0x71f, r[1])) return false;
        io.wr(Gcc, r[0], io.rd(Gcc, r[0]) | 1u);
        if (!io.wait(Gcc, r[0], 1, 0)) return false;
    }
    const uint32_t branches[] = {0x39018, 0x39090, 0x3908c, 0x3902c, 0x39028};
    for (uint32_t r : branches) {
        if (!io.bits(Gcc, r, 1, 1)) return false;
        if (!(io.rd(Gcc, r) & 2u) && !io.wait(Gcc, r, 1u << 31, 0)) return false;
    }
    if (!io.bits(Tcsr, 8, 1, 1) || !io.bits(Gcc, 0x12000, 1, 1)) return false;
    io.delay(5);
    return io.bits(Gcc, 0x12000, 1, 0);
}
inline bool phy(const Io &io) {
    // 38.4 MHz reference, M31 POR and override release, device-mode tuning.
    const uint32_t fields[][3] = {
        {0x94,2,2}, {0x50,2,2}, {0x54,1,1}, {0x154,1,0}, {0xb8,1,1}, {0x54,0x70,0x60},
        {0x16c,0xc,0}, {0x17c,0xf,7}, {0x168,7,0}, {0x15c,3,0},
        {0x64,8,8}, {0x64,4,4}, {0x3c,1,1}, {0x54,2,2}, {0x54,4,0}, {0x50,2,0}, {0x64,8,0}, {0x94,2,0}
    };
    for (const auto &f : fields) if (!io.bits(Phy, f[0], f[1], f[2])) return false;
    if (!io.bits(Scratch, 0x808, 1u << 8, 1u << 8)) return false;
    io.delay(1000);
    if (!io.bits(Scratch, 0x808, 9, 9)) return false;
    io.delay(1000);
    return io.bits(Scratch, 0x808, 1u << 8, 0);
}
inline void vbus(const Io &io, bool present) {
    io.bits(Scratch, 0x830, 1u << 24, present ? 1u << 24 : 0);
    io.bits(Scratch, 0x810, 1u << 20 | 1u << 28, present ? 1u << 20 | 1u << 28 : 0);
}
inline bool core(const Io &io) {
    const uint32_t id = io.rd(Core, 0x120) & 0xffff0000u;
    if (id != 0x55330000 && id != 0x33310000 && id != 0x33320000) return false;
    io.bits(Core, 0x110, 1u << 11, 1u << 11);
    io.delay(100000);
    io.bits(Core, 0x110, 1u << 11 | 3u << 12, 2u << 12);
    io.bits(Core, 0x704, 1u << 31, 0);
    io.wr(Core, 0x704, io.rd(Core, 0x704) | 1u << 30);
    if (!io.wait(Core, 0x704, 1u << 30, 0)) return false;
    io.bits(Core, 0x200, 1u << 6 | 1u << 8, 0);
    io.bits(Core, 0x2c0, 1u << 17, 0);
    vbus(io, false);
    return true;
}
// An exclusive SID entry and unused bank, after the old controller is stopped.
struct SmmuPlan { unsigned slot = ~0u, bank = ~0u, pages = 0; };
template<class Read> inline SmmuPlan smmuPlan(Read read) {
    SmmuPlan p;
    uint32_t idr0 = read(0x20), idr1 = read(0x24), idr2 = read(0x28);
    unsigned groups = idr0 & 255u, banks = idr1 & 255u;
    p.pages = 1u << (((idr1 >> 28) & 7u) + 1u);
    if (!(idr0 & (1u << 30)) || !(idr2 & (1u << 12)) || (idr1 >> 31) || !groups ||
        banks < 2 || banks > 128 || p.pages > 128 || (p.pages + banks) * 4096u > 0x100000) return {};
    for (unsigned shift = 0; shift <= 8; shift += 4) {
        const unsigned code = (idr2 >> shift) & 15u;
        if (code < 1 || code > 5 || (shift == 4 && code < 2)) return {};
    }
    if (groups > 128) groups = 128;
    uint64_t used[2] = {};
    unsigned matches = 0;
    for (unsigned i = 0; i < groups; ++i) {
        const uint32_t smr = read(0x800 + i * 4), s2cr = read(0xc00 + i * 4);
        if (!(smr & (1u << 31))) { if (p.slot == ~0u) p.slot = i; continue; }
        if (((s2cr >> 16) & 3u) == 0) {
            if ((s2cr & 255u) >= banks) return {};
            used[(s2cr & 127u) / 64] |= 1ull << (s2cr & 63u);
        }
        const uint32_t mask = (smr >> 16) & 0x7fffu;
        if (((smr ^ sid) & 0xffffu & ~mask) == 0) {
            if (mask || ++matches > 1) return {};
            p.slot = i;
        }
    }
    for (unsigned b = banks - 1; b-- > 0;) {
        if (!(used[b / 64] & (1ull << (b % 64))) && !(read((p.pages + b) * 4096) & 1u)) { p.bank = b; break; }
    }
    return p;
}
}
