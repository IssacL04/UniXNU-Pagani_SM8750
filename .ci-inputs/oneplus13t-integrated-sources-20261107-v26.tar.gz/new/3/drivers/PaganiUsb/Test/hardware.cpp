// SPDX-License-Identifier: BSD-2-Clause-Patent
#include "../UsbHardware.h"
#include <cassert>
#include <map>
#include <cstdio>
static unsigned waits;
static void IOSleep(unsigned) { ++waits; }
#include "AppsSmmuLock.h"
using namespace paganiusb;
struct Model {
    std::map<uint64_t,uint32_t> regs;
    uint64_t refused = ~0ull;
    unsigned coreReads = 0;
    bool clocked = false, stuckReset = false;
    static uint64_t key(Window w,uint32_t r) { return uint64_t(w) << 32 | r; }
    static uint32_t read(void *p,Window w,uint32_t r) {
        auto &m = *static_cast<Model *>(p);
        if (w == Core || w == Phy || w == Scratch) { assert(m.clocked); if (w == Core) ++m.coreReads; }
        return m.regs[key(w,r)];
    }
    static void write(void *p,Window w,uint32_t r,uint32_t v) {
        auto &m = *static_cast<Model *>(p);
        if (key(w,r) == m.refused) return;
        if (w == Gcc && (r == 0x50018 || r == 0x39004) && !(v & 1)) v |= 1u << 31;
        if (w == Gcc && (r == 0x39030 || r == 0x39048)) v &= ~1u;
        if (w == Gcc && (r == 0x39018 || r == 0x39090 || r == 0x3908c || r == 0x3902c || r == 0x39028)) v &= ~(1u << 31);
        if (w == Core && r == 0x704 && !m.stuckReset) v &= ~(1u << 30);
        m.regs[key(w,r)] = v;
    }
    static void delay(unsigned) {}
    Io io() { return {this,read,write,delay}; }
};
#include "../UsbLogHold.h"
static unsigned holdWaits;
static volatile uint32_t holdWord;
static void holdSleep(unsigned ms) {
    assert(ms == (holdWaits % 2 ? 1000u : 3500u));
    assert(bool(holdWord & (1u << 7)) == bool(holdWaits % 2));
    ++holdWaits;
}
int main() {
    holdWord = 1u << 3;
    { LogHold hold(holdWord, holdSleep, 0); hold.begin(); }
    assert(!holdWaits && holdWord == (1u << 3));
    { LogHold hold(holdWord, holdSleep, 3000); hold.begin(); hold.begin(); assert(holdWord == ((1u << 3) | (1u << 7))); }
    assert(holdWaits == 4 && holdWord == (1u << 3));
    Model m;
    assert(clocks(m.io())); assert(!m.coreReads);
    m.clocked = true;
    assert(phy(m.io()));
    assert((m.regs[Model::key(Phy,0x54)] & 0x77) == 0x63);
    assert(!(m.regs[Model::key(Phy,0x50)] & 2));
    assert((m.regs[Model::key(Scratch,0x808)] & 0x109) == 9);
    assert(!core(m.io()));
    m.regs[Model::key(Core,0x120)] = 0x33313000;
    assert(core(m.io()));
    assert((m.regs[Model::key(Core,0x110)] & 0x3800) == 0x2000);
    vbus(m.io(),true); assert(m.regs[Model::key(Scratch,0x810)] & (1u << 20));
    vbus(m.io(),false); assert(!(m.regs[Model::key(Scratch,0x810)] & (1u << 20)));
    m.stuckReset = true; assert(!core(m.io()));
    Model bad; bad.refused = Model::key(Gcc,0x39018); assert(!clocks(bad.io())); assert(!bad.coreReads);
    m.refused = Model::key(Phy,0x50); assert(!phy(m.io()));
    std::map<uint32_t,uint32_t> smmu = {{0x20,(1u << 30)|8u},{0x24,8},{0x28,(1u << 12)|0x222}};
    auto read = [&](uint32_t r) { return smmu[r]; };
    auto p = smmuPlan(read); assert(p.slot == 0 && p.bank == 6 && p.pages == 2);
    smmu[0x800] = 0x80000060; smmu[0xc00] = 6;
    p = smmuPlan(read); assert(p.slot == 1 && p.bank == 5);
    smmu[(2+5)*4096] = 1;
    p = smmuPlan(read); assert(p.bank == 4);
    smmu[0x804] = 0x80000040; smmu[0xc04] = 0;
    p = smmuPlan(read); assert(p.slot == 1 && p.bank == 4);
    smmu[0x808] = 0x80000040; assert(smmuPlan(read).slot == ~0u);
    smmu[0x808] = 0; smmu[0x804] |= 1u << 16; assert(smmuPlan(read).slot == ~0u);
    smmu[0x804] = 0; smmu[0x28] = 0x1000; assert(smmuPlan(read).bank == ~0u);
    { AppsSmmuLock first; assert(first.ready()); AppsSmmuLock second; assert(!second.ready() && waits == 2000); }
    { AppsSmmuLock next; assert(next.ready()); }
    assert(!sm8750_apps_smmu_busy);
    puts("PASS: USB clocks, PHY, reset failure, VBUS, SMMU ownership and shared lock");
}
